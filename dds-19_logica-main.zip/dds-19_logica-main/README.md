# gitPrimeiro modulo DDS-1-19
Primeiros passos JavaScript :smiley:

Trabalhando com variaveis, laços de repetição e funções!